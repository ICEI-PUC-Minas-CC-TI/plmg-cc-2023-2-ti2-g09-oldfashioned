package dao;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Usuario;

public class UsuarioDAO extends DAO{
	public UsuarioDAO() {
		super();
		conectar();
	}
	public void finalize() {
		close();
	}
	
	//O método recebe um Usuario -> cada atributo desse objeto será transformado em um dado de uma linha na tabela
	public boolean insert(Usuario usuario){
		//Status da conexão:
		boolean status = false;
		try {
		//Cria a conexão:
		//Lembrando que o atributo "conexao" é a Connection herdada da classe Super "DAO"
		Statement st = conexao.createStatement();
		//Criação da Query de Insert (explicação logo embaixo do código)
		String sql = "INSERT INTO usuario (usuario, nome, email, idade, genero, foto, senha) "
		+ "VALUES ("+usuario.getUsuario()+ ", '" + usuario.getNome() + "', '"
		+ usuario.getEmail() + "', '" + usuario.getIdade() + "', '" + usuario.getGenero() + "', '" + usuario.getFoto() + "', '" + usuario.getSenha() + "');";
		//Printa a query no console para conferir se está correta
		System.out.println(sql);
		//Executa a query:
		st.executeUpdate(sql);
		//Fecha a conexão
		st.close();
		status = true;
		} catch (SQLException u) {
			throw new RuntimeException(u);
		}
		return status;
	}

	//o método retorna um ArrayList -> é o array dinâmico de java, em que podem ser inseridos e deletados registros
	public List<Usuario> getAll() {
		//Criação da ArrayList de Usuarios
		List<Usuario> usuarios = new ArrayList<>();
		try {
		//Criação da conexão (os parâmetros indicam que os resultados serão apenas LIDOS)
		Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
		//Essa query retorna toda a tabela:
		String sql = "SELECT * FROM usuario";
		System.out.println(sql);
		//Guarda o resultado da execução da query em um "ResultSet"
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) // enquanto houver registros no ResultSet
		{
		//Cria um objeto Usuario para cada registro da tabela
		Usuario usuario = new Usuario(rs.getString("usuario"), rs.getString("nome"), rs.getString("email"), rs.getInt("idade"), rs.getString("genero"), rs.getString("foto"), rs.getString("senha"));
		//O cliente é adicionado na ArrayList
		usuarios.add(usuario);
		}
		//Conexão fechada
		st.close();
		} catch (Exception e) {
		//Print do possível erro no console
		System.out.println(e.getMessage());
		}
		//ArrayList é retornada
		return usuarios;
	}

	public boolean delete(String user) {
		boolean status = false;
		try {
			Statement st = conexao.createStatement();
			//Deletar da tabela usuario onde o código for igual ao passado
			String sql = "DELETE FROM usuario WHERE usuario = " + user + ";";
			System.out.println(sql);
			st.executeUpdate(sql);
			st.close();
			status = true;
		} catch (SQLException u) {
			throw new RuntimeException(u);
		}
		return status;
	}

	//O método recebe um objeto Usuario que contém os dados novos.
	public boolean update(Usuario user) {
		boolean status = false;
		try {
			Statement st = conexao.createStatement();
			String sql = "UPDATE usuario SET usuario = '" + user.getUsuario() + "', nome = '"
			+ user.getNome() + "', email = '" + user.getEmail() + "', idade = '" + user.getIdade() + "', genero = '" + user.getGenero() + "', foto = '" 
			+ user.getFoto() + "', senha = '" + user.getSenha() + "'" + " WHERE usuario = " + user.getUsuario();
			System.out.println(sql);
			st.executeUpdate(sql);
			st.close();
			status = true;
		} catch (SQLException u) {
			throw new RuntimeException(u);
		}
		return status;
	}

	private List<Usuario> get(String orderBy) {
		List<Usuario> users = new ArrayList<Usuario>();
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM usuario" + ((orderBy.trim().length() == 0) ? "" : (" ORDER BY " + orderBy));
			ResultSet rs = st.executeQuery(sql);	           
	        while(rs.next()) {	            	
	        	Usuario u = new Usuario(rs.getString("usuario"), rs.getString("nome"), rs.getString("email"), rs.getInt("idade"), rs.getString("genero"), rs.getString("foto"), rs.getString("senha"));
				users.add(u);
	        }
	        st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return users;
	}

	public List<Usuario> get() {
		return get("");
	}
	public List<Usuario> getOrderByNome() {
		return get("nome");
	}
	public List<Usuario> getOrderByEmail() {
		return get("email");
	}
	public List<Usuario> getOrderByUsuario() {
		return get("usuario");
	}
}
